const ValidaNumero = {
    variavel1: {
        type: 'number',
    },
    variavel2: {
        type: 'number',
    }
};

module.exports = { ValidaNumero };